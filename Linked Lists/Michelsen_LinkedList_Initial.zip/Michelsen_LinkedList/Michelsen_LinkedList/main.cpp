// This is the main file used to test the implementation of the linked list.
// It contains a test suite for ensuring that the implementation works, and
// a menu that allows the user to run their own custom tests.
//
// Author: Brandon Michelsen
// Date: 9/23/2018

#include <iostream>
#include "linked-list.h"

using namespace std;

int main()
{
	// Create linked list
	LinkedList<int> list;

	/* Test node insertion */
	list.insertNode(1);
	cout << "Head node created: Data = " << list.getHeadPtr()->getData() << endl;

	list.insertNode(2);
	cout << "New node created: Data = " << list.getTailPtr()->getData() << endl;

	list.insertNode(3);
	cout << "New node created: Data = " << list.getTailPtr()->getData() << "\n\n";
	/* End test */

	/* Test node find */
	cout << "Finding the number 3...\n";
	cout << "Node with element 3: " << list.find(3) << endl;

	cout << "NFinding the number 4...\n";
	cout << "Node with element 4: " << list.find(4) << "\n\n";
	/* End test */

	/* Test node deletion */
	cout << "Deleting middle...\n";
	list.deleteNode(list.getTailPtr()->getPrevNode());
	cout << "Deleted.\n";
	cout << "New tail: Data = " << list.getTailPtr()->getData() << endl;

	cout << "Deleting tail...\n";
	list.deleteNode(list.getTailPtr());
	cout << "Deleted.\n";
	cout << "New tail: Data = " << list.getTailPtr()->getData() << endl;

	cout << "Deleting head...\n";
	list.deleteNode(list.getHeadPtr());
	cout << "Deleted.\n";
	cout << "New tail: " << list.getTailPtr() << "\n\n";
	/* End test */

	system("pause");
	return 0;
}