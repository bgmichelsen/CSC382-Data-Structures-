// This is the main file for the Binary Search Tree program.
// It is where the testing of the BinarySearchTree class will
// take place.
//
// Author: Brandon Michelsen
// Date: 10/14/2018

#include <iostream>
#include "BST.h"

using namespace std;

int main()
{
	BinarySearchTree<int> bst = BinarySearchTree<int>();
	
	bst.insertNode(10);
	bst.insertNode(5);
	bst.insertNode(4);
	bst.insertNode(6);
	bst.insertNode(15);
	bst.insertNode(16);
	bst.insertNode(14);

	cout << "Root Node: " << bst.getRoot()->getData() << endl;

	TreeNode<int>* firstLeft = bst.getRoot()->getLeft();
	TreeNode<int>* firstRight = bst.getRoot()->getRight();

	cout << "Left Nodes: \n";
	cout << firstLeft->getData() << endl;
	cout << firstLeft->getLeft()->getData() << endl;
	cout << firstLeft->getRight()->getData() << endl;

	cout << "Right Nodes: \n";
	cout << firstRight->getData() << endl;
	cout << firstRight->getLeft()->getData() << endl;
	cout << firstRight->getRight()->getData() << endl;

	system("pause");
	return 0;
}