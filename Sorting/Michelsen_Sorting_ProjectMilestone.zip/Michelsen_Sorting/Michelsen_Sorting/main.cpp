// This is the main file for the sorting program. It is where the 
// sorting functions are defined and tested. The Linked List project
// from the beginning of the semester is included as part of this 
// project.
//
// Author: Brandon Michelsen

// TO-DO: Implement Quick Sort algorithm
// TO-DO: Implement test suites
// TO-DO: Implement data set input
// TO-DO: Implement timing function
// TO-DO: Structure user interface

#include <iostream>
#include <vector>
#include <limits>
#include <time.h>
#include "linked-list.h"

using namespace std;

// Function prototypes
void insertionSort(LinkedList<int>& list); // Insertion sort algorithm
void quickSort(LinkedList<int>& list); // Quick sort algorithm
void displayList(LinkedList<int>& list); // Function for displaying the list
int checkInput(); // Function for testing user input
bool testSuite(); // Function for the whole test suite
bool testInsertionSort(); // Function for testing insertion sort
bool testQuickSort(); // Fucntion for testing quick sort

int main()
{
	// Declare local variables
	vector<int> data; // Vector for storing the data to add to the list
	LinkedList<int> list; // List to add data to and sort

	// Seed the random number generator
	srand(static_cast<unsigned int>(time(0)));

	// Add data to the vector
	for (int i = 0; i < 20; i++)
		data.push_back((rand()%100)+1);
	// Add the data to the linked list
	for (unsigned int i = 0; i < data.size(); i++)
		list.insertNode(data[i]);

	// Display the list
	cout << "Unsorted List:\n";
	displayList(list);

	// Sort the list
	cout << "\nSorted List (Insertion Sort):\n";
	insertionSort(list);
	displayList(list);

	system("pause");
	return 0;
}

/* Function definitions */

// Check user input function
// Takes no parameters, returns the integer value entered by the user
int checkInput()
{
	// Declare local variables
	int x = 0;

	// While the user has not entered a valid integer, have them try again
	while (!(cin >> x))
	{
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout << "Invalid input. You must enter an integer.\n";
		cout << "Try again: ";
	}

	// Return the value they entered
	return x;
}

// Insertion sort function
// Takes a reference for the linked list to sort, returns void
void insertionSort(LinkedList<int>& list)
{
	// Declare local variables
	int key, temp; // Variables for swapping
	auto current = list.getHeadPtr(); // Get the first element to check
	auto swap = list.getHeadPtr(); // Get the element before the first element to check

	// Make sure we are not sorting an empty list
	if (list.getHeadPtr() == nullptr)
		return;
	else
	{
		// Loop through the list
		while (current->getNextNode() != nullptr)
		{
			// Ensure we are checking the proper nodes
			current = current->getNextNode();
			swap = current->getPrevNode();

			// Get the key to check
			key = current->getData();

			// Check for data that is greater than the key
			while (swap != nullptr && swap->getData() > key)
			{
				// Swap the data that is greater than the key
				temp = swap->getData();
				swap->getNextNode()->setData(temp);
				swap->setData(key);
				swap = swap->getPrevNode();
			}
		}
	}
}

// Quick sort function
// Takes a reference for the linked list to sort, returns void
void quickSort(LinkedList<int>& list)
{

}

// Function to display the list
// Takes a reference for the linked list to display, returns void
void displayList(LinkedList<int>& list)
{
	// Get the head node
	auto current = list.getHeadPtr();

	// Only print the data if it contains less than or equal to 100 elements
	if (list.getSize() > 100)
		cout << "The data set is too large to print.\n";
	else
	{
		cout << "****** Displaying the List *****\n";
		// Run through the list until there are no more elements
		while (current != nullptr)
		{
			cout << current->getData() << endl;
			current = current->getNextNode();
		}
		cout << "****** Done Displaying ******\n";
	}
}

// Whole test suite function
// Takes no parameters, returns a boolean value indicating the success of the tests
bool testSuite()
{
	return (testInsertionSort && testQuickSort);
}

// Test insertion sort function
// Takes no parameters, returns a boolean value indicating the success of the tests
bool testInsertionSort()
{
	return false;
}

// Test quick sort function
// Takes no parameters, returns a boolean value indicating the success of the tests
bool testQuickSort()
{
	return false;
}