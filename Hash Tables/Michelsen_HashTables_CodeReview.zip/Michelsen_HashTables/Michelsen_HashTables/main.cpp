// This is the main file of the program. It is where the hash table will be tested.
//
// Author: Brandon Michelsen
// Date: 11/4/2018

// NOTE: Need to implement getline for the keys
// NOTE: Need to implement test suite
// NOTE: Need to structure program as a phone book

#include <iostream>
#include <string>
#include <limits>
#include <unordered_map>
#include "HashTable.h"

using namespace std;

// Set up a hashing type based on std::hash
struct HashType {
	unsigned long operator()(string key) const
	{
		return hash<string>()(key);
	}
};

// Function prototypes
bool testSuite(); // Testing suite function
int checkInput(); // Function for checking user input
void displayTable(HashTable<string, int, HashType>& hTable); // Function for diaplying the table

int main()
{
	// Declare local variables
	int choice = -1;

	// Create an initialize the hash table
	HashTable<string, int, HashType> hTable;

	do
	{
		cout << "\tWelcome to the Hash Table Program\n";
		cout << "\nChoose an option from the menu below:\n";
		cout << "1) Create and initialize the hash table\n";
		cout << "2) Enter a new value into the hash table\n";
		cout << "3) Retrieve a value from the hash table\n";
		cout << "4) Remove an element from the hash table\n";
		cout << "5) Display the hash table\n";
		cout << "6) Run the automated test suite\n";
		cout << "0) Exit the program\n";

		cout << "Please enter an option from the menu: ";
		cin >> choice;

		// User input variables
		string key;
		int data = 0;

		system("cls");

		// Switch case for the menu options
		switch (choice)
		{
			// Case 0, exit the program
			case 0:
			{
				continue;
				break;
			}
			// Case 1, create the table
			case 1:
			{
				//hTable = HashTable<int>();
				break;
			}
			// Case 2, insert a value
			case 2:
			{
				cout << "Please enter a key for the index: ";
				cin >> key;
				cout << "Please enter a value to insert: ";
				data = checkInput();

				cout << "Key: " << key << endl;
				cout << "Data: " << data << endl;

				hTable.insert(key, data);
				break;
			}
			// Case 3, retrieve a value from the hash table
			case 3:
			{
				cout << "Please enter the key you would like to search for: ";
				cin >> key;

				auto found = hTable.retrieve(key);

				if (found == nullptr)
					cout << "Sorry. The data could not be found.\n";
				else
				{
					cout << "Data found.\n";
					cout << "Key: " << found->key << endl;
					cout << "Data: " << found->data << endl;
				}
				break;
			}
			// Case 4, remove and element from the table
			case 4:
			{
				break;
			}
			// Case 5, display the table
			case 5:
			{
				displayTable(hTable);
				break;
			}
			// Case 6, run the automated test suite
			case 6:
			{
				if (testSuite())
					cout << "****** All tests were successful ******\n";
				else
					cout << "****** Some or all tests failed ******\n";
				break;
			}
			// Default, non-valid option
			default:
			{
				cout << "That is not a valid option.\n";
				break;
			}
		}
		system("pause");
		system("cls");
	} while (choice != 0);

	cout << "Thank you for using this program.\n";
	system("pause");
	return 0;
}

/* Function Definitions */

// Function to check user input
// Takes no parameters, returns the user-entered integer
int checkInput()
{
	// Declare local variables
	int x = 0;

	// While the user is entering incorrect data, have them re-enter
	while (!(cin >> x))
	{
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout << "\nInvalid Input. You must enter an integer.\n";
		cout << "Try again: ";
	}

	// Return the value that the user entered
	return x;
}

// Function for Displaying the Table
// Takes a reference to the hash table, returns void
void displayTable(HashTable<string, int, HashType>& hTable)
{
	cout << "\n*** Displaying the Table ***\n";
	// Get the table
	typename HashTable<string, int, HashType>::TableEntry** table = hTable.getTable();

	// Display the table
	for (int i = 0; i < hTable.getTotalSize(); i++)
	{
		if (table[i] == nullptr)
			cout << "NULL\n";
		else
		{
			cout << "Key: " << table[i]->key << "\t";
			cout << "Data: " << table[i]->data << endl;
		}
	}
	cout << "*** Finished Displaying ***\n";
}

// Test Suite Function
// Takes no parameters, returns a bool for the success of the tests
bool testSuite()
{
	return false;
}