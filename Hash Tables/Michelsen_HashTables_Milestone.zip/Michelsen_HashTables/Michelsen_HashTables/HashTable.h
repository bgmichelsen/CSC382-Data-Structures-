// This file is where the hash table class is defined. The definitions for the hashing function, 
// the insert function, and the retrieve function are given. The class will be using a template
// that gives a generic type for the value V and key K.
//
// 11/4/2018

#ifndef HASH_TABLE_H_
#define HASH_TABLE_H_

#include <string>

template<class V, class K = std::string>
class HashTable 
{
public:
	// Constructor and deconstructor
	HashTable();
	~HashTable();

	// Other functions
	int hash(K key); // Function for hashing the key
	void insert(K key, V val); // Function for inserting a new table entry
	V retrieve(K key); // Function for retrieving a value

private:
	// Struct for a table entry
	struct TableEntry
	{
		K key = NULL;
		V data = NULL;
	};

	// Declare private data members
	const int TABLE_SIZE = 128;
	V table[128];
};

/* Method Definitions */

// Constructor
// Takes no parameters, returns nothing
template<class V, class K = std::string>
HashTable<V, K>::HashTable()
{
	// Initialize the table elements to null pointers
	for (int i = 0; i < TABLE_SIZE; i++)
		table[i] = NULL;
}

// Deconstructor
// Takes no parameters, returns nothing
template<class V, class K = std::string>
HashTable<V, K>::~HashTable()
{

}

// Hashing function
// Takes a parameter for the key, returns the integer value of the hash
template<class V, class K = std::string>
int HashTable<V, K>::hash(K key)
{
	// Variable for the hash
	int hash = 0;

	// Hash the key (use DJB2 algorithm)
	for (int i = 1; i < key.length(); i++)
		hash = ((hash << 5) + hash) + key[i];
	return hash;
}

// Insert function
// Takes parameters for the key and value, returns void
template<class V, class K = std::string>
void HashTable<V, K>::insert(K key, V val)
{
	// Get the index from the hash
	int index = hash(key) % TABLE_SIZE;

	table[index] = val;
}

// Retrieve function
// Takes a parameter
template<class V, class K = std::string>
V HashTable<V, K>::retrieve(K key)
{
	// Get the index from the key
	int index = hash(key) % TABLE_SIZE;

	// Get the data at that index
	return table[index];
}
#endif // HASH_TABLE_H_