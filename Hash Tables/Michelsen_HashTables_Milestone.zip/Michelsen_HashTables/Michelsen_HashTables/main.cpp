// This is the main file of the program. It is where the hash table will be tested.
//
// Author: Brandon Michelsen
// Date: 11/4/2018

#include <iostream>
#include <string>
#include "HashTable.h"

using namespace std;

// Function prototypes
bool testSuite(); // Testing suite function

int main()
{
	HashTable<int> hTable = HashTable<int>();
	string key1 = "Bob";
	string key2 = "Alice";
	string key3 = "George";
	
	cout << "Created Hash Table.\n";
	cout << "\nInserting a new value of 20 with key = Bob.\n";
	hTable.insert(key1, 20);
	cout << "Data inserted: " << hTable.retrieve(key1) << endl;

	cout << "\nInserting a new value of 30 with key = Alice.\n";
	hTable.insert(key2, 30);
	cout << "Data inserted: " << hTable.retrieve(key2) << endl;

	cout << "\nInserting a new value of 40 with key = George.\n";
	hTable.insert(key3, 40);
	cout << "Data inserted: " << hTable.retrieve(key3) << endl;

	system("pause");
	return 0;
}

/* Function Definitions */

// Test Suite Function
// Takes no parameters, returns a bool for the success of the tests
bool testSuite()
{
	return false;
}