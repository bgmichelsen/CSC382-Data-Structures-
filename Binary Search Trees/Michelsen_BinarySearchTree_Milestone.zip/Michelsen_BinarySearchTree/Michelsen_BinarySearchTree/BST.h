// This file provides the class definition and member function definitions
// for the BinarySearchTree class. The binary search tree has a data member 
// that points to the root of the node, and member functions for inserting
// a node, deleting a node, searching for a node, and deleting a node.

// NOTE: There are two insertion functions, one private and one public
// this is to allow for recursion and ease on the user's side.

#ifndef _BST_H
#define _BST_H

#include "TreeNode.h"

template<class T>
class BinarySearchTree
{
public:
	// Constructors
	BinarySearchTree();

	// Getters and setters
	void setRoot(TreeNode<T>* rootPtr); // Method for setting root node
	TreeNode<T>* getRoot(); // Method for getting root node

	// Other methods
	void insertNode(T inData); // Function to insert
	void deleteNode(T delData); // Function to delete a node that contains the given data
	TreeNode<T>* max(); // Function to return the maximum value in the BST
	TreeNode<T>* min(); // Function to find the minimum data member
	TreeNode<T>* find(T dataToFind); // Function for finding data in the BST

private:
	// Declare data members
	TreeNode<T>* root;

	// Private function for insertion (see above)
	void insert(TreeNode<T>*& node, T inData);
};

/* Define member functions */

// Constructor
// Takes no paramters, returns nothing
template<class T>
BinarySearchTree<T>::BinarySearchTree()
{
	// Initialize root pointer
	root = nullptr;
}

// Setter for root pointer
// Takes a pointer for resetting the root, returns void
template<class T>
void BinarySearchTree<T>::setRoot(TreeNode<T>* rootPtr)
{
	root = rootPtr;
}

// Getter for root pointer
// Takes no parameters, returns a pointer to the root
template<class T>
TreeNode<T>* BinarySearchTree<T>::getRoot()
{
	return root;
}

// Insert node method (public)
// Takes in data for the new node, returns void
template<class T>
void BinarySearchTree<T>::insertNode(T inData)
{
	// If the root node is nullptr, set it to contain the new node
	if (root == nullptr)
		root = new TreeNode<T>(inData);
	// Else, if the data is lesser, search to the left of the root
	else if (inData < root->getData())
		insert(root->left, inData);
	// Else, if the data is greater, search to the right
	else if (inData > root->getData())
		insert(root->right, inData);
	// Otherwise, the data matches
	else
		return;
}

// Insertion method (private)
// Takes a parameter for the input data and a node pointer, returns void
template<class T>
void BinarySearchTree<T>::insert(TreeNode<T>*& node, T inData)
{
	// If the current node is a nullptr, set it to contain the proper data
	if (node == nullptr)
		node = new TreeNode<T>(inData);
	// If the data we want is less than the current node's data, search to the left
	else if (inData < node->getData())
		insert(node->left, inData);
	// If the data we want is greater, search to the right
	else if (inData > node->getData())
		insert(node->right, inData);
	// Otherwise, the data matches our current node
	else
		return;
}

// Delete node method
// Takes in data for the node to be deleted, returns void
template<class T>
void BinarySearchTree<T>::deleteNode(T delData)
{

}

// Find max method
// Takes no paramters, returns a pointer to the node containing the maximum data value in the BST
template<class T>
TreeNode<T>* BinarySearchTree<T>::max()
{
	return nullptr;
}

// Find min method
// Takes no parameters, returns a pointer to the node containing the minimum data value in the BST
template<class T>
TreeNode<T>* BinarySearchTree<T>::min()
{
	return nullptr;
}

// Find method
// Takes a paramter for the data to find, returns a pointer to the found node
template<class T>
TreeNode<T>* BinarySearchTree<T>::find(T dataToFind)
{
	return nullptr;
}

#endif // _BST_H

