// This is the main file for the sorting program. It is where the 
// sorting functions are defined and tested. The Linked List project
// from the beginning of the semester is included as part of this 
// project.
//
// Author: Brandon Michelsen

#include <iostream>
#include <vector>
#include <limits>
#include <time.h>
#include <chrono>
#include "linked-list.h"

using namespace std;

// Function prototypes
void insertionSort(LinkedList<int>& list); // Insertion sort algorithm
void quickSort(LinkedList<int>& list, Node<int>* low, Node<int>* high); // Quick sort algorithm
void displayList(LinkedList<int>& list); // Function for displaying the list
Node<int>* quickSortPartition(LinkedList<int>& list, Node<int>* low, Node<int>* high); // Partitioning function for quick sort
int checkInput(); // Function for testing user input
bool testSuite(); // Function for the whole test suite
bool testInsertionSort(); // Function for testing insertion sort
bool testQuickSort(); // Fucntion for testing quick sort

int main()
{
	// Declare local variables
	vector<int> data; // Vector for storing the data to add to the list
	LinkedList<int> list; // List to add data to and sort

	int menuInput = -1; // Variable for the menu input
	chrono::high_resolution_clock::time_point runTimeStart; // Variables for tracking the runtime of sorting functions
	chrono::high_resolution_clock::time_point runTimeEnd;

	// Seed the random number
	srand(static_cast<unsigned int>(time(0)));

	do {
		cout << "\tWelcome to the Sorting Algorithm Program\n\n";
		cout << "Please select an option from the menu below:\n";
		cout << "1) Create data and populate the Linked List.\n";
		cout << "2) Sort the list using Insertion Sort.\n";
		cout << "3) Sort the list using Quicksort.\n";
		cout << "4) Display the linked list.\n";
		cout << "5) Clear the linked list.\n";
		cout << "6) Run the automated test suite.\n";
		cout << "0) Exit the program.\n";

		cout << "\nPlease enter an option from the menu: ";
		menuInput = checkInput();

		system("cls");

		switch (menuInput)
		{
		// Exit the program
		case 0:
		{
			continue;
			break;
		}
		// Create data to populate the linked list
		case 1:
		{
			cout << "How many data items would you like to enter (must be at or greater than 20)?: ";
			int numItems = checkInput();

			while (numItems < 20)
			{
				cout << "That number is less than 20. Please try again: ";
				numItems = checkInput();
			}

			// Create an array of integers to populate the Linked List with
			cout << "\nCreating an array to populate the Linked List with...\n";
			for (int i = 0; i < numItems; i++)
				data.push_back((rand() % 100) + 1);
			cout << "Finished.\n";

			// Populate the Linked List with the data
			cout << "\nPopulating the Linked List with the data...\n";
			for (int i = 0; i < data.size(); i++)
				list.insertNode(data[i]);
			cout << "Finished.\n";

			data.clear();
			break;
		}
		// Sort the list using insertion sort
		case 2:
		{
			cout << "****** Insertion Sort ******\n";
			cout << "\nSorting the list...\n";
			runTimeStart = chrono::high_resolution_clock::now(); // Get the start time
			insertionSort(list);
			runTimeEnd = chrono::high_resolution_clock::now(); // Get the end time
			cout << "Finished.\n";
			cout << "\nTime it took to sort: ";
			cout << chrono::duration_cast<chrono::microseconds>(runTimeEnd - runTimeStart).count();
			cout << " microseconds" << endl;
			break;
		}
		// Sort the list using quicksort
		case 3:
		{
			cout << "****** Quick Sort ******\n";
			cout << "\nSorting the list...\n";
			runTimeStart = chrono::high_resolution_clock::now(); // Get the start time
			quickSort(list, list.getHeadPtr(), list.getTailPtr());
			runTimeEnd = chrono::high_resolution_clock::now(); // Get the end time
			cout << "Finished.\n";
			cout << "\nTime it took to sort: ";
			cout << chrono::duration_cast<chrono::microseconds>(runTimeEnd - runTimeStart).count();
			cout << " microseconds" << endl;
			break;
		}
		// Display the list
		case 4:
		{
			displayList(list);
			break;
		}
		// Clear the linked list
		case 5:
		{
			cout << "Clearing the linked list...\n";
			list.clear();
			cout << "Finished.\n";
			break;
		}
		// Run the automated test suite
		case 6:
		{
			if (testSuite() == true)
				cout << "****** All tests were successful ******\n";
			else
				cout << "****** Some or all tests failed ******\n";
			break;
		}
		// Default - invalid input
		default:
		{
			cout << "That is not a valid input.\n";
			break;
		}
		}
		system("pause");
		system("cls");
	} while (menuInput != 0);

	cout << "Thank you for using our program.\n";
	system("pause");
	return 0;
}

/* Function definitions */

// Check user input function
// Takes no parameters, returns the integer value entered by the user
int checkInput()
{
	// Declare local variables
	int x = 0;

	// While the user has not entered a valid integer, have them try again
	while (!(cin >> x))
	{
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout << "Invalid input. You must enter an integer.\n";
		cout << "Try again: ";
	}

	// Return the value they entered
	return x;
}

// Insertion sort function
// Takes a reference for the linked list to sort, returns void
void insertionSort(LinkedList<int>& list)
{
	// Declare local variables
	int key, temp; // Variables for swapping
	Node<int>* current = list.getHeadPtr(); // Get the first element to check
	Node<int>* swap = list.getHeadPtr(); // Get the element before the first element to check

	// Make sure we are not sorting an empty list
	if (list.getHeadPtr() == nullptr)
		return;
	else
	{
		// Loop through the list
		while (current->getNextNode() != nullptr)
		{
			// Ensure we are checking the proper nodes
			current = current->getNextNode();
			swap = current->getPrevNode();

			// Get the key to check
			key = current->getData();

			// Check for data that is greater than the key
			while (swap != nullptr && swap->getData() > key)
			{
				// Swap the data that is greater than the key
				temp = swap->getData();
				swap->getNextNode()->setData(temp);
				swap->setData(key);
				swap = swap->getPrevNode();
			}
		}
	}
}

// Quick sort function
// Takes a reference for the linked list to sort, returns void
void quickSort(LinkedList<int>& list, Node<int>* low, Node<int>* high)
{
	// Declare local variables
	Node<int>* p; // Variable for the partition

	// Ensure we are not sorting an empty list
	if (list.getHeadPtr() == nullptr)
		return;
	else
	{
		// Ensure we don't give a stack overflow error
		if (high != nullptr && low != high && low != high->getNextNode())
		{
			p = quickSortPartition(list, low, high); // Get the proper partition

			// Recursive calls for proper sorting
			quickSort(list, low, p->getPrevNode());
			quickSort(list, p->getNextNode(), high);
		}
	}
}

// Quick sort partition function
// Takes a reference for the linked list to sort, returns an int
Node<int>* quickSortPartition(LinkedList<int>& list, Node<int>* low, Node<int>* high)
{
	// Declare local variables
	int pivot = high->getData(); // Select the pivot value
	Node<int>* swap = low; // Node variable for swapping values
	Node<int>* next = low; // Node variable for running through the partition
	int temp = 0; // Temporary variable for swapping values

	// Cycle through the partition
	while (next != high)
	{
		// If the data in the current node is less than or equal to the pivot, swap
		if (next->getData() <= pivot)
		{
			// Swap the data
			temp = next->getData();
			next->setData(swap->getData());
			swap->setData(temp);

			// Get the next swap node
			swap = swap->getNextNode();
		}
		// Continue cycling through the partition
		next = next->getNextNode();
	}
	
	// Final swap
	temp = high->getData();
	high->setData(swap->getData());
	swap->setData(temp);

	// Return the swp node as the next partition
	return swap;
}


// Function to display the list
// Takes a reference for the linked list to display, returns void
void displayList(LinkedList<int>& list)
{
	// Get the head node
	auto current = list.getHeadPtr();

	// Only print the data if it contains less than or equal to 100 elements
	if (list.getSize() > 100)
		cout << "The data set is too large to print.\n";
	else
	{
		cout << "****** Displaying the List *****\n";
		// Run through the list until there are no more elements
		while (current != nullptr)
		{
			cout << current->getData() << endl;
			current = current->getNextNode();
		}
		cout << "****** Done Displaying ******\n";
	}
}

// Whole test suite function
// Takes no parameters, returns a boolean value indicating the success of the tests
bool testSuite()
{
	return (testInsertionSort() && testQuickSort());
}

// Test insertion sort function
// Takes no parameters, returns a boolean value indicating the success of the tests
bool testInsertionSort()
{
	// Declare local variables
	bool testSort = true; // Variable for tracking test success and failure
	LinkedList<int> testList; // List for testing sorting on

	cout << "****** Insertion Sort Test Function ******\n";
	// Add data to the list
	cout << "Adding elements to the list...\n";
	testList.insertNode(10);
	testList.insertNode(1);
	testList.insertNode(5);
	cout << "Elements currently in the list:\n";
	cout << "10\n";
	cout << "1\n";
	cout << "5\n";

	/* Test Insertion Sort */
	cout << "Testing insertion sort...\n";
	insertionSort(testList);

	// Test if the value of 1 was sorted to the correct spot
	if (testList.getHeadPtr()->getData() == 1)
		cout << "SUCCESS - Element containing value of 1 successfully sorted to first element.\n";
	else
	{
		cout << "FAIL - Element containing value of 1 failed to be sorted to first element.\n";
		testSort = false;
	}

	// Test if the value of 5 was sorted to the correct spot
	if (testList.getHeadPtr()->getNextNode()->getData() == 5)
		cout << "SUCCESS - Element containing value of 5 successfully sorted to second element.\n";
	else
	{
		cout << "FAIL - Element containing value of 5 failed to be sorted to second element.\n";
		testSort = false;
	}

	// Test if the value of ten was sorted to the correct spot
	if (testList.getTailPtr()->getData() == 10)
		cout << "SUCCESS - Element containing value of 10 successfully sorted to third element.\n";
	else
	{
		cout << "FAIL - Element containing value of 10 failed to be sorted to third element.\n";
		testSort = false;
	}

	cout << "****** End Insertion Sort Test ******\n\n";

	return testSort;
}

// Test quick sort function
// Takes no parameters, returns a boolean value indicating the success of the tests
bool testQuickSort()
{
	// Declare local variables
	bool testSort = true; // Variable for tracking test success and failure
	LinkedList<int> testList; // List for testing on

	cout << "****** Quicksort Test Function ******\n";

	// Add data to the list
	cout << "Adding data to the list...\n";
	testList.insertNode(10);
	testList.insertNode(1);
	testList.insertNode(5);
	cout << "Elements currently in the list:\n";
	cout << "10\n";
	cout << "1\n";
	cout << "5\n";

	/* Test the partition function */
	cout << "Testing the partition function...\n";
	auto middleNode = testList.getHeadPtr()->getNextNode();

	if (quickSortPartition(testList, testList.getHeadPtr(), testList.getTailPtr()) == middleNode)
		cout << "SUCCESS - The partition function returned the correct node as the pivot.\n";
	else
	{
		cout << "FAIL - The partition function failed to return the correct node as the pivot.\n";
		testSort = false;
	}
	/* End Partition Function Test */

	/* Test quicksort */
	cout << "Testing quicksort...\n";
	quickSort(testList, testList.getHeadPtr(), testList.getTailPtr());

	// Test if the value of 1 was sorted to the correct spot
	if (testList.getHeadPtr()->getData() == 1)
		cout << "SUCCESS - Element containing value of 1 successfully sorted to first element.\n";
	else
	{
		cout << "FAIL - Element containing value of 1 failed to be sorted to first element.\n";
		testSort = false;
	}

	// Test if the value of 5 was sorted to the correct spot
	if (testList.getHeadPtr()->getNextNode()->getData() == 5)
		cout << "SUCCESS - Element containing value of 5 successfully sorted to second element.\n";
	else
	{
		cout << "FAIL - Element containing value of 5 failed to be sorted to second element.\n";
		testSort = false;
	}

	// Test if the value of ten was sorted to the correct spot
	if (testList.getTailPtr()->getData() == 10)
		cout << "SUCCESS - Element containing value of 10 successfully sorted to third element.\n";
	else
	{
		cout << "FAIL - Element containing value of 10 failed to be sorted to third element.\n";
		testSort = false;
	}

	cout << "****** End Quicksort Test ******\n\n";

	return testSort;
}