// This file defines the TreeNode class along with its data members and member functions. 
// The TreeNode class has data members for stored data, a pointer to the next node to the left, 
// and a pointer to the next node to the right. The member functions are the getter and setter 
// functions for each of these data members.

#ifndef _TREE_NODE_H
#define _TREE_NODE_H

template<class T>
class TreeNode
{
public:
	// Constructors and de-constructors
	TreeNode(); // Default constructor
	TreeNode(T inData); // Constructor
	~TreeNode(); // Default de-constructor

	// Getters and setters
	void setData(T inData); // Setter for data
	T getData(); // Getter for data
	void setLeft(TreeNode<T>* leftPtr); // Setter for left node
	TreeNode<T>* getLeft(); // Getter for left node
	void setRight(TreeNode<T>* rightPtr); // Setter for right node
	TreeNode<T>* getRight(); // Getter for right node

	// Public data members
	TreeNode<T>* left; // Pointer for left node
	TreeNode<T>* right; // Pointer for right node

private:
	// Private data members
	T data; // Variable for data
};

/* Define member methods */

// Default constructor
// Takes no parameters, returns nothing
template<class T>
TreeNode<T>::TreeNode()
{
	// Initialize the internal data
	data = NULL;
	left = nullptr;
	right = nullptr;
}

// Custom constructor
// Takes a parameter for the initial data, returns nothing
template<class T>
TreeNode<T>::TreeNode(T inData)
{
	// Initialize the data
	data = inData;
	left = nullptr;
	right = nullptr;
}

// Deconstructor
// Takes no parameters, returns nothing
template<class T>
TreeNode<T>::~TreeNode()
{
	data = NULL;
	left = nullptr;
	right = nullptr;
}

// Setter for the data
// Takes a parameter for input data, returns void
template<class T>
void TreeNode<T>::setData(T inData)
{
	data = inData;
}

// Getter for the data
// Takes no parameters, returns the data
template<class T>
T TreeNode<T>::getData()
{
	return data;
}

// Setter for the left node
// Takes a pointer for resetting the left node, returns void
template<class T>
void TreeNode<T>::setLeft(TreeNode<T>* leftPtr)
{
	left = leftPtr;
}

// Getter for the left node
// Takes no parameters, returns a pointer to the left node
template<class T>
TreeNode<T>* TreeNode<T>::getLeft()
{
	return left;
}

// Setter for the right node
// Takes a pointer for resetting the right node, returns void
template<class T>
void TreeNode<T>::setRight(TreeNode<T>* rightPtr)
{
	right = rightPtr;
}

// Getter for the right node
// Takes no parameters, returns a pointer to the right node
template<class T>
TreeNode<T>* TreeNode<T>::getRight()
{
	return right;
}

#endif // _TREE_NODE_H

