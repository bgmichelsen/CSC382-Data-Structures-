// This file contains the class definition, along with data members and methods, 
// for the linked list. The functionality is described in comments throughout the 
// code. The class uses templates to make the implementation more generic.
//
// Author: Brandon Michelsen
// Date: 9/23/2018

// Only include the header file once
#ifndef LINKED_LIST_H
#define LINKED_LIST_H

// Include necessary files
#include "node.h"

/* Class definition */
template<class T>
class LinkedList 
{
public:
	// Constructors
	LinkedList(); // Default constructor

	// Getters and setters
	void setHeadPtr(Node<T>* headPtr); // Function to set the head of the linked list
	Node<T>* getHeadPtr(); // Function to get the head of the linekd list
	void setTailPtr(Node<T>* tailPtr); // Function to set the tail of the linked list
	Node<T>* getTailPtr(); // Function to get the tail of the linked list

	// Other methods
	Node<T>* find(T dataToFind); // Function to find a node with dataToFind
	void insertNode(T newData); // Function to insert new node at the tail of the list
	void deleteNode(Node<T>* delNode); // Function to delate the node at delNode

private:
	// Declare data members
	Node<T>* head;
	Node<T>* tail;
};

/* Method definitions */

// Default constructor
// No parameters, no return value
template<class T>
LinkedList<T>::LinkedList()
{
	head = nullptr;
	tail = nullptr;
}

// Set head ptr function
// Takes a parameter for the new head ptr, returns void
template<class T>
void LinkedList<T>::setHeadPtr(Node<T>* headPtr)
{
	head = headPtr;
}

// Get head ptr function
// Takes no paramters, returns the head of the linked list
template<class T>
Node<T>* LinkedList<T>::getHeadPtr()
{
	return head;
}

// Set tail ptr function
// Takes parameter for the new tail ptr, returns void
template<class T>
void LinkedList<T>::setTailPtr(Node<T>* tailPtr)
{
	tail = tailPtr;
}

// Get tail ptr function
// Takes no paramters, returns the tail of the linked list
template<class T>
Node<T>* LinkedList<T>::getTailPtr()
{
	return tail;
}

// Find function
// Takes a paramter for the data to find, returns a pointer to the node where the data was found
template<class T>
Node<T>* LinkedList<T>::find(T dataToFind)
{
	// Create a node for searching, set it to the head
	Node<T>* currentNode = head;

	// Loop until the data is found or until the tail is reached
	while (currentNode != nullptr && currentNode->getData() != dataToFind)
	{
		currentNode = currentNode->getNextNode();
	}

	return currentNode;
}

// Insert function
// Takes a parameter for the data to insert with the new node, returns void
template<class T>
void LinkedList<T>::insertNode(T newData)
{
	Node<T>* newNode = new Node<T>(newData);

	if (head == nullptr)
	{
		// If this is the first node...
		head = newNode; // Set the head to be the new node
		tail = newNode; // Set the tail to be the new node
	}
	else
	{
		// Otherwise...
		tail->setNextNode(newNode); // Set the next node from the tail to point to the new node
		newNode->setPrevNode(tail); // Set the previous node from the new node to be the tail
		tail = newNode; // Reset the tail to be the new node
	}
}

// Delete function
// Takes a parameter for a pointer to the node to delete, returns void
template<class T>
void LinkedList<T>::deleteNode(Node<T>* delNode)
{
	if (delNode->getPrevNode() != nullptr)
	{
		// If a previous node exists, set its net node to be the node after delNode
		delNode->getPrevNode()->setNextNode(delNode->getNextNode());
	}
	else
	{
		// Otherwise, set the head node to be the node after delNode
		head = delNode->getNextNode();
	}

	if (delNode->getNextNode() != nullptr)
	{
		// If a next node exists, set its previous node to the node before delNode
		delNode->getNextNode()->setPrevNode(delNode->getPrevNode());
	}
	else
	{
		// If delNode is the tail node, reset the tail node to be the node before delNode
		tail = delNode->getPrevNode();
	}

	// Delete delNode
	delete delNode;
}

#endif // LINKED_LIST_H
