#include "BST.h"

int main()
{
	BinarySearchTree<int> bst = BinarySearchTree<int>();

	bst.insertNode(10);
	bst.insertNode(16);
	bst.insertNode(5);

	return 0;
}